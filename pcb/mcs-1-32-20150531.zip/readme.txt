Drill data (EXCELLON)
*.drd : drill data
*.dri : drill information

Gerber data (GERBER-274-X)
*.cmp : tracks, top side
*.sol : tracks, bottom side
*.stc : solder stop mask, top side
*.sts : solder stop mask, bottom side
*.plc : silkscreen, top side
*.pls : silkscreen, bottom side
*.out : outline
